package com.mio.myapplicationjmcg

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class activityPromedio : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_promedio)
    }
}