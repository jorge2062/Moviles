package com.mio.myapplicationjmcg

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ActivityEstadist : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_estadist)
    }
}