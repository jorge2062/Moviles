package com.mio.myapplicationjmcg

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class ActivityMenu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        val primerBoton: Button =findViewById(R.id.button3)
        primerBoton.setOnClickListener{onClick(1)}
        val segundBoton: Button =findViewById(R.id.button4)
        segundBoton.setOnClickListener{onClick(2)}


    }

    private fun onClick(button: Int) {
        when(button){
            1->{
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
            2->{
                val intent = Intent(this, ActivityEstadist::class.java)
                startActivity(intent)
            }
        }
    }


}

